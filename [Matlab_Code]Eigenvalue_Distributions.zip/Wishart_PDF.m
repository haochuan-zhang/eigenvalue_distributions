function y = Wishart_PDF(x, N, ell, Wishart_only)
INT_LIMIT = 80;

LIMIT_LOW = 0; %For Wishart, this value is 0; for GOE/GUE/GSE, it is -INT_LIMIT
LIMIT_UP = +INT_LIMIT;

M = Wishart_only.M;
rho_vec = Wishart_only.rho_vec;

x=x.';
lenX = length(x);

CorrMat = zeros(N,N);
for ii = 1:N
    for jj = 1:N
        CorrMat(ii,jj) = (-1/(2* rho_vec(ii)))^(jj-1);
    end
end
K_Wishart = ...
    pi^(N^2/2)* 2^(-M*N/2) * (prod(rho_vec))^(-M/2) ...
    / Gamma_m_a(N,N/2) / Gamma_m_a(N,M/2) ...
    * prod(factorial([0:N-1]))/ det(CorrMat);

% K_Wishart = ...
%     pi^(N^2/2)* 2^(-M*N/2) * (prod(rho_vec))^(-M/2) ...
%     / Gamma_m_a(N,N/2) / Gamma_m_a(N,M/2) ...
%     * prod(gamma(N-[1-1:N-1]/2)???) / det(CorrMat);


coeff = K_Wishart / factorial(ell-1) / factorial(N-ell);
y = zeros(lenX,1); % essential to initialize at zero



sigmaMat = perms([1:N]); % sigmaMat size: factorial(m) * m
for pLoop = 1:factorial(N)    
    % Construct matrix
    disp('Matrix Generating!');        
    sigmaVec = sigmaMat(pLoop,:);
    if mod(N,2) == 0 %N even, matrix should be size NxN
        Atensor = zeros(N, N, lenX);% important to initialize as 0
        for ii = 1:N
            for jj = 1:ii-1
                disp(['ii=', num2str(ii), ', jj=', num2str(jj)])
                func2 = @(xx,yy) sign(yy-xx) .* xx.^((M-N-1)/2) .* exp(-xx/2/rho_vec(ii)) .* yy.^((M-N-1)/2) .* exp(-yy/2/rho_vec(jj));
                %func1x = @(xx) sign(tt-xx) .* xx.^((M-N-1)/2) .* exp(-xx/2/rho_vec(ii)) .* tt.^((M-N-1)/2) .* exp(-tt/2/rho_vec(jj)); %func2(xx,tt);
                %func1y = @(yy) sign(yy-tt) .* tt.^((M-N-1)/2) .* exp(-tt/2/rho_vec(ii)) .* yy.^((M-N-1)/2) .* exp(-yy/2/rho_vec(jj)); %func2(tt,yy);
                func_x_part = @(xx) xx.^((M-N-1)/2) .* exp(-xx/2/rho_vec(ii));
                func_y_part = @(yy) yy.^((M-N-1)/2) .* exp(-yy/2/rho_vec(jj));
                for xLoop = 1:lenX
                    tt = x(xLoop);
                    if sigmaVec(ii)<ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, xLoop) = integral2(func2, tt, LIMIT_UP, tt, LIMIT_UP, 'AbsTol',1e-2, 'Method','iterated');                        
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)==ell                        
                        Atensor(ii, jj, xLoop) = -1* func_y_part(tt) * integral(func_x_part, tt, LIMIT_UP, 'AbsTol',1e-2);  
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)>ell                        
                        Atensor(ii, jj, xLoop) = -1 ...
                            * integral(func_x_part, tt, LIMIT_UP, 'AbsTol',1e-2, 'Method','iterated') ...
                            * integral(func_y_part, LIMIT_LOW, tt, 'AbsTol',1e-2, 'Method','iterated');
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)<ell                        
                        Atensor(ii, jj, xLoop) = +1 * func_x_part(tt) * integral(func_y_part, tt, LIMIT_UP, 'AbsTol',1e-2);
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)==ell
                        Atensor(ii, jj, xLoop) = 0;
                        
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)>ell                        
                        Atensor(ii, jj, xLoop) = -1 * func_x_part(tt) * integral(func_y_part, LIMIT_LOW, tt, 'AbsTol',1e-2);                        
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)<ell                        
                        Atensor(ii, jj, xLoop) = +1 ...
                            * integral(func_x_part, LIMIT_LOW, tt, 'AbsTol',1e-2) ...
                            * integral(func_y_part, tt, LIMIT_UP, 'AbsTol',1e-2);                        
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)==ell                        
                        Atensor(ii, jj, xLoop) = +1 * func_y_part(tt) *integral(func_x_part, LIMIT_LOW, tt, 'AbsTol',1e-2);
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)>ell
                        Atensor(ii, jj, xLoop) = integral2(func2, LIMIT_LOW, tt, LIMIT_LOW, tt, 'AbsTol',1e-2, 'Method','iterated');
                    else
                        error('Wrong sigmaVec!!!') 
                    end
                end %xLoop
            end %jj
        end %ii
        
    else %N odd, matrix should be size (N+1)x(N+1)        
        Atensor = zeros(N+1, N+1, lenX);% important to initialize as 0        
        for ii = 1:N
            for jj = 1:ii-1
                disp(['ii=', num2str(ii), ', jj=', num2str(jj)])
                func2 = @(xx,yy) sign(yy-xx) .* xx.^((M-N-1)/2) .* exp(-xx/2/rho_vec(ii)) .* yy.^((M-N-1)/2) .* exp(-yy/2/rho_vec(jj));
                %func1x = @(xx) sign(tt-xx) .* xx.^((M-N-1)/2) .* exp(-xx/2/rho_vec(ii)) .* tt.^((M-N-1)/2) .* exp(-tt/2/rho_vec(jj)); %func2(xx,tt);
                %func1y = @(yy) sign(yy-tt) .* tt.^((M-N-1)/2) .* exp(-tt/2/rho_vec(ii)) .* yy.^((M-N-1)/2) .* exp(-yy/2/rho_vec(jj)); %func2(tt,yy);
                func_x_part = @(xx) xx.^((M-N-1)/2) .* exp(-xx/2/rho_vec(ii));
                func_y_part = @(yy) yy.^((M-N-1)/2) .* exp(-yy/2/rho_vec(jj));
                for xLoop = 1:lenX
                    tt = x(xLoop);
                    if sigmaVec(ii)<ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, xLoop) = integral2(func2, tt, LIMIT_UP, tt, LIMIT_UP, 'AbsTol',1e-2, 'Method','iterated');                        
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)==ell                        
                        Atensor(ii, jj, xLoop) = -1* func_y_part(tt) * integral(func_x_part, tt, LIMIT_UP, 'AbsTol',1e-2);  
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)>ell                        
                        Atensor(ii, jj, xLoop) = -1 *...
                            integral(func_x_part, tt, LIMIT_UP, 'AbsTol',1e-2) * ...
                            integral(func_y_part, LIMIT_LOW, tt, 'AbsTol',1e-2);
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)<ell                        
                        Atensor(ii, jj, xLoop) = +1 * func_x_part(tt) * integral(func_y_part, tt, LIMIT_UP, 'AbsTol',1e-2);
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)==ell
                        Atensor(ii, jj, xLoop) = 0;
                        
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)>ell                        
                        Atensor(ii, jj, xLoop) = -1 * func_x_part(tt) * integral(func_y_part, LIMIT_LOW, tt, 'AbsTol',1e-2);                        
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)<ell                        
                        Atensor(ii, jj, xLoop) = +1 * ...
                            integral(func_x_part, LIMIT_LOW, tt, 'AbsTol',1e-2) * ...
                            integral(func_y_part, tt, LIMIT_UP, 'AbsTol',1e-2);                        
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)==ell                        
                        Atensor(ii, jj, xLoop) = +1 * func_y_part(tt) *integral(func_x_part, LIMIT_LOW, tt, 'AbsTol',1e-2);
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)>ell
                        Atensor(ii, jj, xLoop) = integral2(func2, LIMIT_LOW, tt, LIMIT_LOW, tt, 'AbsTol',1e-2, 'Method','iterated');
                    else
                        error('Wrong sigmaVec!!!') 
                    end
                end %xLoop
            end %jj            
            
           %%%%%%%%%%%%%%%%%%%%%%%
            % Last column            
            func_x_part = @(xx) xx.^((M-N-1)/2) .* exp(-xx/2/rho_vec(ii));
            for xLoop = 1:lenX
                tt = x(xLoop);
                if sigmaVec(ii)<ell
                    Atensor(ii, N+1, xLoop) = integral(func_x_part, tt, LIMIT_UP, 'AbsTol',1e-2);
                elseif sigmaVec(ii)==ell
                    Atensor(ii, N+1, xLoop) = func_x_part(tt);
                else %sigmaVec(ii)>ell
                    Atensor(ii, N+1, xLoop) = integral(func_x_part, LIMIT_LOW, tt, 'AbsTol',1e-2);
                end %end if
            end 
            
        end %ii
               
        
    end % both even and odd N
    
    %Make the matrix skew-symmetric
    for xLoop = 1:lenX
        Atensor(:, :, xLoop) = Atensor(:, :, xLoop) - Atensor(:, :, xLoop).';
    end
    
    % Calculating determinant of the tensor        
    %% Method 1: zhc
    y = y+ coeff * Pf2D(Atensor);       

end %pLoop

end    

function res = Gamma_m_a(mm, aa) %multivariate Gamma function [Muirhead-Book82, Theorem 2.1.12]
res = pi^(mm*(mm-1)/4) * prod( gamma(aa-[0:mm-1]/2) ) ;
end

