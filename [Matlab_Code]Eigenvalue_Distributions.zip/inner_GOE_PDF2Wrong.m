function y = inner_GOE_PDF2(x, N, ell)
x=x.';
lenX = length(x);
%C1_GOE = ( 2^(N/2)* prod(gamma([1:N]/2)) )^(-1);
beta=1;
C1_GOE = factorial(N) * (2*pi)^(-N/2)* beta^(N*(N-1)*beta/4 +N/2)*...
    prod(gamma(1+beta/2)./gamma(1+beta*[1:N]/2)) ;
coeff = C1_GOE * (-1)^((N-1)^2 + ell+1)/ factorial(ell-1) / factorial(N-ell);
y = zeros(lenX,1); % essential to initialize at zero

sigmaMat = perms([1:N-1]); % sigmaMat size: factorial(m) * m
for pLoop = 1:factorial(N-1)    
    % Construct matrix
    disp('Matrix Generating!');        
    sigmaVec = sigmaMat(pLoop,:);    
    if mod(N-1,2) == 0 %N-1 even, matrix should be size NxN
        Atensor = zeros(N-1, N-1, lenX);% important to initialize as 0
        for ii = 1:N-1            
            for jj = 1:N-1%ii-1
                disp(['ii=', num2str(ii), ', jj=', num2str(jj)])
                    
                    if sigmaVec(ii)<ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, :) = F_posInf(ii, x).*F_posInf(jj, x) - 2*tildF_posInf(ii,jj,x);
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)>=ell
                        Atensor(ii, jj, :) = F_posInf(ii, x).*F_negInf(jj, x);
                    elseif sigmaVec(ii)>=ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, :) = -F_negInf(ii, x).*F_posInf(jj, x);
                    elseif sigmaVec(ii)>=ell && sigmaVec(jj)>=ell
                        Atensor(ii, jj, :) = -F_negInf(ii, x).*F_negInf(jj, x) - 2*tildF_negInf(ii,jj,x);
                    else
                        error('Wrong sigmaVec!!!')
                    end
                    
                    % skew-symmetric
                    %Atensor(jj, ii, :) = -Atensor(ii, jj, :);
            end %jj
        end%ii   
        Atensor(:,:,[1:20])
        
    else %N-1 odd, matrix should be size NxN        
        Atensor = zeros(N, N, lenX);% important to initialize as 0
        for ii = 1:N-1            
            for jj = 1:N-1%ii-1
                disp(['ii=', num2str(ii), ', jj=', num2str(jj)])
                    
                    if sigmaVec(ii)<ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, :) = F_posInf(ii, x).*F_posInf(jj, x) - 2*tildF_posInf(ii,jj,x);
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)>=ell
                        Atensor(ii, jj, :) = F_posInf(ii, x).*F_negInf(jj, x);
                    elseif sigmaVec(ii)>=ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, :) = -F_negInf(ii, x).*F_posInf(jj, x);
                    elseif sigmaVec(ii)>=ell && sigmaVec(jj)>=ell
                        Atensor(ii, jj, :) = -F_negInf(ii, x).*F_negInf(jj, x) - 2*tildF_negInf(ii,jj,x);
                    else
                        error('Wrong sigmaVec!!!')
                    end
                    
                    % skew-symmetric
                    %Atensor(jj, ii, :) = -Atensor(ii, jj, :);
            end %jj
        end%ii      
                
        for ii = 1:N-1 
            % for last column
            if sigmaVec(ii)<ell
                Atensor(ii, N, :) = F_posInf(ii, x);                 
            else
                Atensor(ii, N, :) = -F_negInf(ii, x);
            end %end if            
            
            % Ske-symmetric, for last row
            Atensor(N, ii, :) = -Atensor(ii, N, :);
        end %ii
        
    end %
    

    for xLoop = 1:lenX
            Atensor(:, :, xLoop) = 1/2 * (Atensor(:, :, xLoop) - Atensor(:, :, xLoop).');
    end
    
    
    % Calculating determinant of the tensor        
    %% Method 1: zhc
    y = y+ coeff .* exp(-1/2*x.^2) .* Pf2D(Atensor);       
    
    %% Method 2:
%      for xLoop=1:lenX
%          y(xLoop) = y(xLoop)+ coeff .* exp(-1/2*x(xLoop).^2) .* pfaffian_householder(permute(Atensor(xLoop,:,:),[2,3,1]));
%      end
        
end %pLoop

end    


function res = F_posInf(ii, x)
    res = 2^((ii-1)/2)*...
        (...
        gamma((ii+1)/2)* hypergeom(-ii/2,1/2,-x.^2/2) ...
        - ...
        sqrt(2)*x.* gamma(ii/2+1) .* hypergeom((1-ii)/2,3/2,-x.^2/2) ...
        );
end

function res = F_negInf(ii, x)
    res = -1* (-1)^ii * 2^((ii-1)/2)*...
        (...
        gamma((ii+1)/2)* hypergeom(-ii/2,1/2,-x.^2/2) ...
        + ...
        sqrt(2)*x.* gamma(ii/2+1) .* hypergeom((1-ii)/2,3/2,-x.^2/2) ...
        );
end


function res = tildF_posInf(ii,jj,x)
    res = exp(-x.^2).*...
        (...
        0.5* gamma((ii+jj+1)/2)* hypergeom((ii+jj+1)/2,1/2,x.^2) ...
        - ...
        x.* gamma((ii+jj+2)/2) .* hypergeom((ii+jj+2)/2,3/2,x.^2) ...
        );
end

function res = tildF_negInf(ii,jj,x)
    res = (-1)^(ii+jj)* exp(-x.^2).*...
        (...
        0.5* gamma((ii+jj+1)/2)* hypergeom((ii+jj+1)/2,1/2,x.^2) ...
        + ...
        x.* gamma((ii+jj+2)/2) .* hypergeom((ii+jj+2)/2,3/2,x.^2) ...
        );
end
