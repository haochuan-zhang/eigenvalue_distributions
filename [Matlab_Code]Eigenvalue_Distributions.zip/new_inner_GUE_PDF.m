function y = new_inner_GUE_PDF(x, N, ell)
beta=2;

lenX = length(x);
%y = zeros(lenX, 1);

C2_GUE = 2^(N*(N-1)/2) / ( pi^(N/2) * prod(gamma(1:N)) );
    
    %for ell = 1:N
    coeff =  C2_GUE /( factorial(ell-1)* factorial(N-ell) );
    Atensor = zeros(lenX, N, N, N); % initialize with 0, important!!!
    % Construct rank-3 tensor
    disp('Rank-3 Tensor Generating!');
    
    for kk = 1:N
        if kk < ell
            for ii = 1:N
                for jj = 1:N
                    Atensor(:, ii, jj, kk) =  Omega_fun(+1, x, ii+jj-1, beta);
                end
            end
        elseif kk > ell
            for ii = 1:N
                for jj = 1:N
                    Atensor(:, ii, jj, kk) =  Omega_fun(-1, x, ii+jj-1, beta);
                end
            end
        else% kk== ell
            for ii=1:N
                for jj=1:N
                    Atensor(:, ii, jj, kk) = x.^(ii+jj-2) .* exp( -x.^2);
                end
            end           
        end %if
        
    end %kk
    
    % Calculating determinant of the tensor
        %Important: $\mathcal{T}(\{a_{i,j,k}\}) \neq  \mathcal{T}(\{a_{j,i,k}\}) \neq \mathcal{T}(\{a_{i,k,j}\}) \neq \mathcal{T}(\{a_{k,j,i}\})...$.
        %In other words, the operation $\mathcal{T}(\cdot)$ is NOT  ``permutation-preserving''!
    disp('Determinant Calculating!');
    %     for xloop = 1:lenX    
    %         y(xloop) = coeff * det3D(Atensor(xloop, :,:,:));
    %     end
    y = coeff * det4D(Atensor);
    %end % ell
    
end    

