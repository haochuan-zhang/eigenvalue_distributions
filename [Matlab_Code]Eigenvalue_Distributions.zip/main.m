clc 
clear all
close all

EnsType = 'Wishart_Uncorrelated' % Gaussian ensemble type:  'GOE', 'GUE', 'GSE', 'Wishart', 'Wishart_Uncorrelated'
N = 3           % size of the square matrix
len = 1e5       % number of random (matrix) samples
numBins = 30    % number of bins for counting (i.e., the histogram PDF)
dirMat = './mats/'
dirFig = './figs/'

Wishart_only.M = N+2           % ONLY for Wishart_N(M, Sigma),where M>=N, Sigma: NxN, Wishart NxN.
Wishart_only.CORR= 0.9         % correlation coefficient for generating the correlation matrix Sigma 0<CORR<=1
% Sigma = zeros(N);
% for ii = 1:N
%     for jj=1:N
%         Sigma(ii, :) = Wishart_only.CORR.^(abs(ii-jj));
%     end
% end
rho_vec = linspace(Wishart_only.CORR,0.1,N); % sort(eig(Sigma),'descend');
rho_vec = N/sum(rho_vec) * rho_vec
Wishart_only.rho_vec = rho_vec; %sort(rand(N,1),'descend')           % ONLY for Wishart, it is the distinct non-zero eigenvalues of Sigma: NxN.

checkOK_rho = length(Wishart_only.rho_vec)==N && isempty(find(Wishart_only.rho_vec<=0,1)) && length(unique(Wishart_only.rho_vec))==N
if ~checkOK_rho %
    error('rho_vec must have N positive and distinct values!');
end

% preparation for looping
nVec = N*ones(N,1); % nVec = [4, 4, 4, 4]; %% matrix size
kVec = 1:N;         % kVec = [1, 2, 3, 4]; %% eigenvalues (largest -> smallest) 
for loop1=1:length(kVec)
    ell = kVec(loop1)	
	N = nVec(loop1)
    
    eigenvalue = generateEV(N,len, EnsType, dirMat, Wishart_only);
	kthEV = eigenvalue(ell,:);
	clear eigenvalue
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% % Plot Linear-Linear PDF Figure     
	% simulation     
	[count, abscissa] = hist(kthEV,numBins);
	figure(loop1)
	ordinate = count/sum(count.*(abscissa-[0,abscissa(1:end-1)]));
	bar(abscissa, ordinate);
	minEV = min(kthEV);
    maxEV = max(kthEV);
	hold on

    x = linspace(minEV, maxEV, numBins);
%     
%     % Zanella's   
% 	figure(loop1)
% 	hold on
%     f1_x = minEVcorrelated(x,m,n,R);
% 	plot(x,f1_x, '-ko');
%     
     % Ours
     
     figure(loop1)
     switch EnsType
         case 'GOE'
             %f2_x = inner_GOE_PDF(x, N, ell);
             f2_x = new_inner_GOE_PDF(x, N, ell);
         case 'GUE'
             %f2_x = inner_GUE_PDF(x, N, ell);
             f2_x = new_inner_GUE_PDF(x, N, ell);             
         case 'GSE'
             %f2_x = inner_GSE_PDF(x, N, ell);
             f2_x = new_inner_GSE_PDF(x, N, ell);
         case 'Wishart'
            %% ZHC 2020-03-07:
            %% The Hyerpergeometric Function of REAL matrix arguments is indeed NOT KNOWN [Muirhead-Book82], 
            %% despite the fact that the Hypergeom Func of COMPLEX matrix arguments could be rewritten in terms of matrix determinants [Khatri-70].
             
             %f2_x = Wishart_PDF(x, N, ell, Wishart_only);
             pre_f2_x = Wishart_PDF(x, N, ell, Wishart_only);
             norm_coeff=trapz(x,pre_f2_x);
             f2_x = pre_f2_x/norm_coeff;
         
         case 'Wishart_Uncorrelated'
             f2_x = Wishart_Uncorrelated_PDF(x, N, ell, Wishart_only);
         otherwise
             error('Ensemble type not supported!');
     end
       
     plot(x,f2_x, '-kx')     
     legend('Simulation','Ours')
     fig_name = sprintf('%s%s_N%s_ell%s_1e%s-%s.fig', dirFig, EnsType, num2str(N), num2str(ell),num2str(log10(len)), date);     
     savefig(loop1, fig_name);
     mat_name = sprintf('%s%s_N%s_ell%s_1e%s-%s.mat', dirMat, EnsType, num2str(N), num2str(ell),num2str(log10(len)), date);
     save(mat_name)
end


	% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% % get normalized factor for the approximate PDF
	% x = [0:0.1:30];
	% CDF = quadl(@approxPDF,x(1),x(end),1e-6,[], k,m,n)
	% figure(1)
	% plot(x, approxPDF(x,k,m,n), '-ko');
	% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




