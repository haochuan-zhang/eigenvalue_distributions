function result = Pf3D(Amat)
% Amat: dimension lenX, 2N, 2N, N
% usage: Amat(xloop, ii, jj, kk)

%Important:
%$\mathcal{T}(\{a_{i,j,k}\}) \neq  \mathcal{T}(\{a_{j,i,k}\}) \neq \mathcal{T}(\{a_{i,k,j}\}) \neq \mathcal{T}(\{a_{k,j,i}\})...$.
%In other words, the operation $\mathcal{T}(\cdot)$ is NOT  ``permutation-preserving''!


[lenX, numRow, numCol, numPage] = size(Amat);
if (numRow ~= numCol || numRow ~= 2*numPage)
    error('3 dimension does not agree!');
end
N2 = numRow;%2N
N = numRow/2;

pVec = perms([1:N2]); % pVec: [factorial(N2), N2]

%signP = signPerm(pVec); % signP: [1, factorial(N2)] %% ZHC's code
signP = power(-1, permutationparity(pVec,2)); %% StackExchange's code


result = zeros(lenX, 1);
for  pLoop = 1: factorial(N2)    
        prodTemp = ones(lenX, 1);
        for jj = 1:N
            prodTemp = prodTemp .* Amat(:, pVec(pLoop, 2*jj-1), pVec(pLoop, 2*jj), jj);
        end
        result = result + signP(pLoop)*prodTemp;    
end
%result = 1/(2^N * factorial(N)) * result;
end
