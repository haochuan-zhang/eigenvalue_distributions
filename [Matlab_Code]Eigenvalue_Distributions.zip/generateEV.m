function eigenvalue = generateEV(N, len, EnsType, dirMat, Wishart_only)

% % system parameters
% N=4
% len = 1e4
strMat = sprintf('%s%s_N%s_1e%s.mat',dirMat, EnsType, num2str(N),num2str(log10(len)));
if strcmp(EnsType, 'Wishart') || strcmp(EnsType, 'Wishart_Uncorrelated')
    strMat = sprintf('%s%s_N%s_1e%s_M%s.mat',dirMat, EnsType, num2str(N),num2str(log10(len)), num2str(Wishart_only.M));
end
if strcmp(EnsType, 'Wishart') || strcmp(EnsType, 'Wishart_Uncorrelated')
    strMat = sprintf('%s%s_N%s_1e%s_M%s_rho%s.mat',dirMat, EnsType, num2str(N),num2str(log10(len)), num2str(Wishart_only.M), num2str(Wishart_only.CORR));
end
    

if(exist(strMat) ~= 0) % if existed, load it
    disp('.mat file existed!');
    load(strMat);     
    eigenvalue = eigenvalue;
    return;
end
% if not existed, generate the random matrix now
disp('New random matrices generating!');

eigenvalue = zeros(N,len); % [N, len] % first row is the largest eigenvalue




if strcmp(EnsType, 'GOE') || strcmp(EnsType, 'GUE') || strcmp(EnsType, 'GSE')
    switch EnsType
        case 'GOE'
            Zmat = randn(N, N, len);
        case 'GUE'
            Zmat = 1/sqrt(2) * (randn(N, N, len) + 1i*randn(N, N, len));
        case 'GSE' %the matrix will be 2N x 2N in size
            Xmat = 1/2 *  (randn(N, N, len) + 1i*randn(N, N, len));
            Ymat = 1/2 *  (randn(N, N, len) + 1i*randn(N, N, len));
            Zmat = [Xmat, Ymat; -conj(Ymat), conj(Xmat)];
            
            % Y = randn(N)+ 1i*randn(N);
            % G = [X, Y; -conj(Y), conj(X)]
            % GSE= (G+G')/2
            % eig(GSE) % eigenvalues of multiplicity-2
        
        otherwise
            error('Ensemble type not supported!');
    end
    % obtain eigenvalue
    for loop1 = 1:len
        Amat = 1/2 * (Zmat(:,:,loop1)+Zmat(:,:,loop1)');
        if strcmp(EnsType, 'GSE') % for GSE, eigenvalues of multiplicity-2
            tmp_ev = sort(eig(Amat));   % eig() returns a vector whose first element is the smallest eigenvalue
            eigenvalue(:,loop1) = tmp_ev([2*N:-2:1]);
        else
            eigenvalue([N:-1:1],loop1) = sort(eig(Amat));   % eig() returns a vector whose first element is the smallest eigenvalue
        end
    end
    
    
else % Wishart or Wishart_Uncorrelated
    M = Wishart_only.M;
    rho_vec = Wishart_only.rho_vec;
    if strcmp(EnsType, 'Wishart_Uncorrelated')
        rho_vec(:) = 1;
    end
    Hmat = randn(N,M, len);
    for loop1 = 1:len
        Wmat = diag(sqrt(rho_vec))* Hmat(:,:,loop1) * Hmat(:,:,loop1)' * diag(sqrt(rho_vec));
        eigenvalue([N:-1:1],loop1) = sort(eig(Wmat)); 
    end
end

save(strMat,'EnsType', 'N', 'len', 'eigenvalue');

end