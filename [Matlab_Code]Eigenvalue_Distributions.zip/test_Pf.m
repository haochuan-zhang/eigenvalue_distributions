function test_Pf
clear all
clc
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% For Pf_Bruijn() only the skew-symmetric part is in effect, while the symmetric part is not.
%% Which is true for any matrix, even-size or odd-size, real or complex, skew or not.
is_real=0
N = 3
if is_real==1
    A_mat = randn(N,N)
    Sym_mat = 1/2* (A_mat+A_mat');
    B_mat = randn(N,N)
    Ant_mat = 1/2* (B_mat-B_mat');
else
    A_mat = randn(N,N)+1i*randn(N,N)
    Sym_mat = 1/2* (A_mat+transpose(A_mat));
    B_mat = randn(N,N)+1i*randn(N,N)
    Ant_mat = 1/2* (B_mat-transpose(B_mat));
end
Pf_Bruijn(Sym_mat+Ant_mat)-Pf_Bruijn(Ant_mat)
Pf_Bruijn(A_mat)-Pf_Bruijn(1/2*(A_mat-A_mat.'))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 
% N=3
% theta = sort(randn(N,1),'descend') % ascend
% Amat = zeros(N,N);
% for ii=1:N
%     Amat(ii,:) = exp(1j*theta(ii)*([1:N] -1)); 
% end
% Amat
% Bmat = [zeros(N,N), Amat; -Amat.', zeros(N,N)]
% abs(det(Amat))
% det(Bmat)%== det(U*Sigma*U.')== det(Sigma) == Pf^2(Sigma)
% Pf_Bruijn(Bmat)^2
% abs(Pf_Bruijn(Bmat))


end

function result = Pf_Bruijn(Amat)
% usage: Amat(ii, jj, xloop)


[numRow, numCol, lenX] = size(Amat);
if (numRow ~= numCol)
    error('2 dimension does not agree!');
end
N2 = numRow;%2N
N = floor(numRow/2);

pVec = perms([1:N2]); % pVec: [factorial(N2), N2]

%signP = signPerm(pVec); % signP: [1, factorial(N2)] %% ZHC's code
signP = power(-1, permutationparity(pVec,2)); %% StackExchange's code


result = zeros(lenX, 1);
for  pLoop = 1: factorial(N2)    
        prodTemp = ones(lenX, 1);
        for jj = 1:N
            prodTemp = prodTemp .* permute(Amat(pVec(pLoop, 2*jj-1), pVec(pLoop, 2*jj), :), [3,2,1]);
        end
        result = result + signP(pLoop)*prodTemp;    
end
result = 1/(2^N * factorial(N)) * result;

end












