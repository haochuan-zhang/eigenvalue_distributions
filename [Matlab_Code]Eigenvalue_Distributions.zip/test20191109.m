clear all
clc
close all


N = 3

Amat = randn(2*N)
Pf2D(Amat)
pfaffian_householder(Amat/2-Amat.'/2)

%%%%%%%%%%%%%%%%%%%%
% ii=2
% jj=3
% t=randn(1,2)
% func = @(x,y) sign(y-x) .* x.^ii .* exp(-(x+t).^2/2) .* y.^jj .* exp(-(y+t).^2/2)
% q1 = integral2(func, 0, +inf, 0, +inf)
% q2 = integral2(func, 0, +inf, -inf, 0)
% q3 = integral2(func, -inf, 0, 0, +inf)
% q4 = integral2(func, -inf, 0, -inf, 0)
%%%%%%%%%%%%%%%%%
% %Test the GSE eigenvalues
% 
% %Tracy: The Distribution of the Largest Eigenvalue in the Gaussian Ensembles: �� = 1, 2, 4
% % Edelman: Random matrices
% 
% N = 2
% X = randn(N)+ 1i*randn(N);
% Y = randn(N)+ 1i*randn(N);
% G = [X, Y; -conj(Y), conj(X)]
% GSE= (G+G')/2
% eig(GSE) % eigenvalues of multiplicity-2
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % test constant
% N= randi(10)
% C_1N =  factorial(N)*(2*pi)^(-N/2)* (gamma(3/2))^N * prod(1./gamma(1+[1:N]/2))
% C_1N_my = (2)^(-N/2) * prod(1./gamma([1:N]/2)) 
% abs(C_1N-C_1N_my)
