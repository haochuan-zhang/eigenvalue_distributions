function y = inner_GSE_PDF(x, N, ell)


lenX = length(x);
%y = zeros(lenX, 1);
beta=4;
C4_GSE = factorial(N) * (2*pi)^(-N/2)* beta^(N*(N-1)*beta/4 +N/2)*...
    prod(gamma(1+beta/2)./gamma(1+beta*[1:N]/2)) ;
    
    %for ell = 1:N
    coeff =  C4_GSE /( factorial(ell-1)* factorial(N-ell) );
    Atensor = zeros(lenX, 2*N, 2*N, N); % initialize with 0, important!!!
    % Construct rank-3 tensor
    disp('Rank-3 Tensor Generating!');
    
    for kk = 1:N
        if kk < ell
            for ii = 1:2*N
                for jj = 2:2*N
                    Atensor(:, ii, jj, kk) = (jj-1)* intgrRpositive(x, ii, jj);
                end
            end
        elseif kk > ell
            for ii = 1:2*N
                for jj = 2:2*N
                    Atensor(:, ii, jj, kk) = (jj-1)* intgrRnegative(x, ii, jj);
                end
            end
        else% kk== ell                        
                Atensor(:, 1, 2, kk) = exp( -2* x.^2);                                         
                % the remaingings are zero, i.e., Atensor(i, j, kk, :) = 0;
        end %if
        
    end %kk
    
    % Calculating determinant of the tensor
        %Important: $\mathcal{T}(\{a_{i,j,k}\}) \neq  \mathcal{T}(\{a_{j,i,k}\}) \neq \mathcal{T}(\{a_{i,k,j}\}) \neq \mathcal{T}(\{a_{k,j,i}\})...$.
        %In other words, the operation $\mathcal{T}(\cdot)$ is NOT  ``permutation-preserving''!
    disp('Determinant Calculating!');
    %     for xloop = 1:lenX    
    %         y(xloop) = coeff * det3D(Atensor(xloop, :,:,:));
    %     end
    y = coeff * Pf3D(Atensor);
    %end % ell
    
end    



function output = intgrRpositive(x, ii, jj)
    output = ...
        2^(-ii/2-jj/2) * exp(-2* x.^2) .*...
        ( ...
          gamma((ii+jj-2)/2) * hypergeom((ii+jj-2)/2, 1/2, 2*x.^2)  ...
          - ... 
          2*sqrt(2) * gamma((ii+jj-1)/2) * hypergeom((ii+jj-1)/2, 3/2, 2*x.^2) .* x ...
        );
end

function output = intgrRnegative(x, ii, jj)
    output = ...
        (-1)^(ii+jj+1) *2^(-ii/2-jj/2) * exp(-2*x.^2) .*...
        ( ...
          gamma((ii+jj-2)/2) * hypergeom((ii+jj-2)/2, 1/2, 2*x.^2)  ...
          + ... 
          2*sqrt(2) * gamma((ii+jj-1)/2) * hypergeom((ii+jj-1)/2, 3/2, 2*x.^2) .* x ...
        );
end
    