function result = Pf_Bruijn(Amat)
% usage: Amat(ii, jj, xloop)


[numRow, numCol, lenX] = size(Amat);
if (numRow ~= numCol)
    error('2 dimension does not agree!');
end
N2 = numRow;%2N
N = floor(numRow/2);

pVec = perms([1:N2]); % pVec: [factorial(N2), N2]

%signP = signPerm(pVec); % signP: [1, factorial(N2)] %% ZHC's code
signP = power(-1, permutationparity(pVec,2)); %% StackExchange's code


result = zeros(lenX, 1);
for  pLoop = 1: factorial(N2)    
        prodTemp = ones(lenX, 1);
        for jj = 1:N
            prodTemp = prodTemp .* permute(Amat(pVec(pLoop, 2*jj-1), pVec(pLoop, 2*jj), :), [3,2,1]);
        end
        result = result + signP(pLoop)*prodTemp;    
end
result = 1/(2^N * factorial(N)) * result;

end




