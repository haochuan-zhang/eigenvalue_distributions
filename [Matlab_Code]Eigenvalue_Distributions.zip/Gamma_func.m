function q = Gamma_func(varargin) % Gamma(n, x) or Gamma(n)
    if nargin==1
        q = gamma(varargin{1});
    elseif nargin==2 % 
        % gammainc(X, n, 'upper')= 1/Gamma(n) *int_X^inf e^(-t) t^(n-1) dt: gammainc is normalized in Matlab
        q = gamma(varargin{1})* gammainc(varargin{2}, varargin{1}, 'upper');
    else
        error('number of parameters for Gamma_func should not exceed 2!');
    end
end