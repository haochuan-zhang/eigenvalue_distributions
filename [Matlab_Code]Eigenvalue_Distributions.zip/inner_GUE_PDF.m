function y = inner_GUE_PDF(x, N, ell)


lenX = length(x);
%y = zeros(lenX, 1);

C2_GUE = 2^(N*(N-1)/2) / ( pi^(N/2) * prod(gamma(1:N)) );
    
    %for ell = 1:N
    coeff =  C2_GUE /( factorial(ell-1)* factorial(N-ell) );
    Atensor = zeros(lenX, N, N, N); % initialize with 0, important!!!
    % Construct rank-3 tensor
    disp('Rank-3 Tensor Generating!');
    
    for kk = 1:N
        if kk < ell
            for ii = 1:N
                for jj = 1:N
                    Atensor(:, ii, jj, kk) =  intgrRpositive(x, ii+jj-2);
                end
            end
        elseif kk > ell
            for ii = 1:N
                for jj = 1:N
                    Atensor(:, ii, jj, kk) =  intgrRnegative(x, ii+jj-2);
                end
            end
        else% kk== ell
            Atensor(:, 1, 1, kk) = exp( -x.^2);
            % the remaingings are zero, i.e., Atensor(i, j, kk, :) = 0;
        end %if
        
    end %kk
    
    % Calculating determinant of the tensor
        %Important: $\mathcal{T}(\{a_{i,j,k}\}) \neq  \mathcal{T}(\{a_{j,i,k}\}) \neq \mathcal{T}(\{a_{i,k,j}\}) \neq \mathcal{T}(\{a_{k,j,i}\})...$.
        %In other words, the operation $\mathcal{T}(\cdot)$ is NOT  ``permutation-preserving''!
    disp('Determinant Calculating!');
    %     for xloop = 1:lenX    
    %         y(xloop) = coeff * det3D(Atensor(xloop, :,:,:));
    %     end
    y = coeff * det4D(Atensor);
    %end % ell
    
end    


function output = intgrRpositive(x, kk)
    output = ...
        1/2 * exp(-x.^2) .*...
        ( ...
          gamma((kk+1)/2) * hypergeom((kk+1)/2, 1/2, x.^2)  ...
          - ... 
          2 * gamma((kk+2)/2) * hypergeom((kk+2)/2, 3/2, x.^2) .* x ...
        );
end

function output = intgrRnegative(x, kk)
    output = ...
        (-1)^(kk+2) *1/2 * exp(-x.^2) .*...
        ( ...
          gamma((kk+1)/2) * hypergeom((kk+1)/2, 1/2, x.^2)  ...
          + ... 
          2 * gamma((kk+2)/2) * hypergeom((kk+2)/2, 3/2, x.^2) .* x ...
        );
end
    