function y = inner_GOE_PDF(x, N, ell)
INT_LIMIT = 20;

x=x.';
lenX = length(x);
%C1_GOE = ( 2^(N/2)* prod(gamma([1:N]/2)) )^(-1);
beta=1;
C1_GOE = factorial(N) * (2*pi)^(-N/2)* beta^(N*(N-1)*beta/4 +N/2)*...
    prod(gamma(1+beta/2)./gamma(1+beta*[1:N]/2)) ;
coeff = C1_GOE * (-1)^((N-1)^2 + ell+1)/ factorial(ell-1) / factorial(N-ell);
y = zeros(lenX,1); % essential to initialize at zero

sigmaMat = perms([1:N-1]); % sigmaMat size: factorial(m) * m
for pLoop = 1:factorial(N-1)    
    % Construct matrix
    disp('Matrix Generating!');        
    sigmaVec = sigmaMat(pLoop,:);
    if mod(N-1,2) == 0 %N-1 even, matrix should be size NxN
        Atensor = zeros(N-1, N-1, lenX);% important to initialize as 0
        for ii = 1:N-1
            for jj = 1:ii-1
                disp(['ii=', num2str(ii), ', jj=', num2str(jj)])
                for xLoop = 1:lenX
                    tt = x(xLoop);
                    func = @(xx,yy) sign(yy-xx) .* xx.^ii .* exp(-(xx+tt).^2/2) .* yy.^jj .* exp(-(yy+tt).^2/2);
                    if sigmaVec(ii)<ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, xLoop) = integral2(func, 0, +INT_LIMIT, 0, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)>=ell
                        Atensor(ii, jj, xLoop) = F_posInf(ii, x(xLoop)).*F_negInf(jj, x(xLoop));
                    elseif sigmaVec(ii)>=ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, xLoop) = -F_negInf(ii, x(xLoop)).*F_posInf(jj, x(xLoop));
                    elseif sigmaVec(ii)>=ell && sigmaVec(jj)>=ell
                        Atensor(ii, jj, xLoop) = integral2(func, -INT_LIMIT, 0, -INT_LIMIT, 0, 'AbsTol',1e-2, 'Method','iterated');
                    else
                        error('Wrong sigmaVec!!!')
                    end
                end %xLoop
            end %jj
        end %ii
        
    else %N-1 odd, matrix should be size NxN        
        Atensor = zeros(N, N, lenX);% important to initialize as 0
        for ii = 1:N-1
            for jj = 1:ii-1
                disp(['ii=', num2str(ii), ', jj=', num2str(jj)])
                for xLoop = 1:lenX
                    tt = x(xLoop);
                    func = @(xx,yy) sign(yy-xx) .* xx.^ii .* exp(-(xx+tt).^2/2) .* yy.^jj .* exp(-(yy+tt).^2/2);
                    if sigmaVec(ii)<ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, xLoop) = integral2(func, 0, +INT_LIMIT, 0, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)>=ell
                        Atensor(ii, jj, xLoop) = F_posInf(ii, x(xLoop)).*F_negInf(jj, x(xLoop));
                    elseif sigmaVec(ii)>=ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, xLoop) = -F_negInf(ii, x(xLoop)).*F_posInf(jj, x(xLoop));
                    elseif sigmaVec(ii)>=ell && sigmaVec(jj)>=ell
                        Atensor(ii, jj, xLoop) = integral2(func, -INT_LIMIT, 0, -INT_LIMIT, 0, 'AbsTol',1e-2, 'Method','iterated');
                    else
                        error('Wrong sigmaVec!!!')
                    end
                end %xLoop
            end %jj
        end %ii 
                
        for ii = 1:N-1
            if sigmaVec(ii)<ell
				Atensor(ii, N, :) = F_posInf(ii, x);  
%                 Atensor(ii, N, :) = 2^((ii-1)/2)*...
%                     (...
%                     gamma((ii+1)/2)*hypergeom(-ii/2, 1/2, -x.^2/2) ...
%                     - sqrt(2)*x * gamma(ii/2 +1) .*hypergeom((1-ii)/2, 3/2, -x.^2/2) ...
%                     );
            else
				Atensor(ii, N, :) = -F_negInf(ii, x);
%                 Atensor(ii, N, :) = (-1)^ii *2^((ii-1)/2)*...
%                     (...
%                     gamma((ii+1)/2)*hypergeom(-ii/2, 1/2, -x.^2/2) ...
%                     + sqrt(2)*x * gamma(ii/2 +1) .*hypergeom((1-ii)/2, 3/2, -x.^2/2) ...
%                     );
            end %end if            
        end %ii
        
        
    end %
    
    % Make the matrix skew-symmetric
    for xLoop = 1:lenX
        Atensor(:, :, xLoop) = Atensor(:, :, xLoop) - Atensor(:, :, xLoop).';
    end
    
    % Calculating determinant of the tensor        
    %% Method 1: zhc
    y = y+ coeff .* exp(-1/2*x.^2) .* Pf2D(Atensor);       

end %pLoop

end    

function res = F_posInf(ii, x)
    res = 2^((ii-1)/2)*...
        (...
        gamma((ii+1)/2)* hypergeom(-ii/2,1/2,-x.^2/2) ...
        - ...
        sqrt(2)*x.* gamma(ii/2+1) .* hypergeom((1-ii)/2,3/2,-x.^2/2) ...
        );
end

function res = F_negInf(ii, x)
    res = -1* (-1)^ii * 2^((ii-1)/2)*...
        (...
        gamma((ii+1)/2)* hypergeom(-ii/2,1/2,-x.^2/2) ...
        + ...
        sqrt(2)*x.* gamma(ii/2+1) .* hypergeom((1-ii)/2,3/2,-x.^2/2) ...
        );
end