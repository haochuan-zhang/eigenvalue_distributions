function result = det3D(Amat)
%Important:
%$\mathcal{T}(\{a_{i,j,k}\}) \neq  \mathcal{T}(\{a_{j,i,k}\}) \neq \mathcal{T}(\{a_{i,k,j}\}) \neq \mathcal{T}(\{a_{k,j,i}\})...$.
%In other words, the operation $\mathcal{T}(\cdot)$ is NOT  ``permutation-preserving''!
[numRow, numCol, numPage] = size(Amat);
if (numRow ~= numCol || numRow ~= numPage || numCol ~= numPage)
    error('3 dimension does not agree!');
end
m = numRow;
pVec = perms([1:m]); % pVec: [factorial(m), m]
qVec = pVec;
%signP = signPerm(pVec); % signP: [1, factorial(m)] %% ZHC's code
signP = power(-1, permutationparity(pVec,2)); %% StackExchange's code
signQ = signP;


result = 0;
for  pLoop = 1: factorial(m)
    for qLoop = 1:factorial(m)
        prodTemp = 1;
        for k = 1:m
            prodTemp = prodTemp * Amat(pVec(pLoop, k), qVec(qLoop, k), k);
        end
        result = result + signP(pLoop)*signQ(qLoop)*prodTemp;
    end
end

end

function result = signPerm(permVec)

[row col] = size(permVec);
result = ones(1,row);

for k = 1:row
    for i = 1:col
       for j = i+1:col
               if permVec(k,i) > permVec(k,j)
                   result(k) = -result(k); 
               end
       end
    end
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ������ά�����Ƿ���ȷ
% m = 3
% n = m
% K = 1/prod(factorial(m-[1:m]))/prod(factorial(n-[1:m]));
% Gmat = zeros(m-1,m-1,m-1);
% % construct 3-D matrix
% for ii = 1:m-1
%     for jj = 1:m-1
%         for kk = 1:m-1
%             Gmat(ii,jj,kk) = factorial(ii+jj+0);
%         end
%     end
% end
% detGmat = det3D(Gmat)
% detGmat*K/factorial(m-1) Ӧ�õ���m


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % ����2D���������ʽ.
% [numRow, numCol] = size(Amat);
% m = numRow;
% pVec = perms([1:m]); % pVec: [factorial(m), m]
% signP = signPerm(pVec); % signP: [1, factorial(m)]
% 
% 
% 
% result = 0;
% for  pLoop = 1: factorial(m)
% 
%         prodTemp = 1;
%         for k = 1:m
%             prodTemp = prodTemp * Amat(pVec(pLoop, k),  k);
%         end
%         result = result + signP(pLoop)*prodTemp;
% 
% end

