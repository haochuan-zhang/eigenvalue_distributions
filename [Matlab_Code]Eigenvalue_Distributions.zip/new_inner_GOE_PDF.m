function y = new_inner_GOE_PDF(x, N, ell)
INT_LIMIT = 20;

x=x.';
lenX = length(x);
%C1_GOE = ( 2^(N/2)* prod(gamma([1:N]/2)) )^(-1);
beta=1;
C1_GOE = factorial(N) * (2*pi)^(-N/2)* beta^(N*(N-1)*beta/4 +N/2)*...
    prod(gamma(1+beta/2)./gamma(1+beta*[1:N]/2)) ;

coeff = C1_GOE / factorial(ell-1) / factorial(N-ell);
y = zeros(lenX,1); % essential to initialize at zero

sigmaMat = perms([1:N]); % sigmaMat size: factorial(m) * m
for pLoop = 1:factorial(N)    
    % Construct matrix
    disp('Matrix Generating!');        
    sigmaVec = sigmaMat(pLoop,:);
    if mod(N,2) == 0 %N even, matrix should be size NxN
        Atensor = zeros(N, N, lenX);% important to initialize as 0
        for ii = 1:N
            for jj = 1:ii-1
                disp(['ii=', num2str(ii), ', jj=', num2str(jj)])
                for xLoop = 1:lenX
                    tt = x(xLoop);
                    func2 = @(xx,yy) sign(yy-xx) .* xx.^(ii-1) .* exp(-xx.^2/2) .* yy.^(jj-1) .* exp(-yy.^2/2);
                    %func1x = @(xx) sign(tt-xx) .* xx.^(ii-1) .* exp(-xx.^2/2) .* tt.^(jj-1) .* exp(-tt.^2/2);
                    %func1y = @(yy) sign(yy-tt) .* tt.^(ii-1) .* exp(-tt.^2/2) .* yy.^(jj-1) .* exp(-yy.^2/2);
                    
                    if sigmaVec(ii)<ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, xLoop) = integral2(func2, tt, +INT_LIMIT, tt, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');                        
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)==ell
                        %Atensor(ii, jj, xLoop) = integral(func1x, tt, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = -tt^(jj-1)*exp(-tt^2/2)*Omega_fun(+1,tt,ii, beta);
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)>ell
                        %Atensor(ii, jj, xLoop) = integral2(func2, tt, +INT_LIMIT, -INT_LIMIT, tt, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = -Omega_fun(+1,tt,ii, beta)*Omega_fun(-1,tt,jj, beta);
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)<ell
                        %Atensor(ii, jj, xLoop) = integral(func1y, tt, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = tt^(ii-1)*exp(-tt^2/2)*Omega_fun(+1,tt,jj, beta);
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)==ell
                        Atensor(ii, jj, xLoop) = 0;
                        
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)>ell
                        %Atensor(ii, jj, xLoop) = integral(func1y, -INT_LIMIT, tt, 'AbsTol',1e-2, 'Method','iterated');                        
                        Atensor(ii, jj, xLoop) = -tt^(ii-1)*exp(-tt^2/2)*Omega_fun(-1,tt,jj, beta);
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)<ell
                        %Atensor(ii, jj, xLoop) = integral2(func2, -INT_LIMIT, tt, tt, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = Omega_fun(-1,tt,ii, beta)*Omega_fun(+1,tt,jj, beta);
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)==ell
                        %Atensor(ii, jj, xLoop) = integral(func1x, -INT_LIMIT, tt, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = tt^(jj-1)*exp(-tt^2/2)*Omega_fun(-1,tt,ii, beta);
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)>ell
                        Atensor(ii, jj, xLoop) = integral2(func2, -INT_LIMIT, tt, -INT_LIMIT, tt, 'AbsTol',1e-2, 'Method','iterated');
                    else
                        error('Wrong sigmaVec!!!') 
                    end
                end %xLoop
            end %jj
        end %ii
        
    else %N odd, matrix should be size (N+1)x(N+1)        
        Atensor = zeros(N+1, N+1, lenX);% important to initialize as 0        
        for ii = 1:N
            for jj = 1:ii-1
                disp(['ii=', num2str(ii), ', jj=', num2str(jj)])
                for xLoop = 1:lenX
                    tt = x(xLoop);
                    func2 = @(xx,yy) sign(yy-xx) .* xx.^(ii-1) .* exp(-xx.^2/2) .* yy.^(jj-1) .* exp(-yy.^2/2);
                    %func1x = @(xx) sign(tt-xx) .* xx.^(ii-1) .* exp(-xx.^2/2) .* tt.^(jj-1) .* exp(-tt.^2/2);
                    %func1y = @(yy) sign(yy-tt) .* tt.^(ii-1) .* exp(-tt.^2/2) .* yy.^(jj-1) .* exp(-yy.^2/2);
                    
                    if sigmaVec(ii)<ell && sigmaVec(jj)<ell
                        Atensor(ii, jj, xLoop) = integral2(func2, tt, +INT_LIMIT, tt, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');                        
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)==ell
                        %Atensor(ii, jj, xLoop) = integral(func1x, tt, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = -tt^(jj-1)*exp(-tt^2/2)*Omega_fun(+1,tt,ii, beta);
                    elseif sigmaVec(ii)<ell && sigmaVec(jj)>ell
                        %Atensor(ii, jj, xLoop) = integral2(func2, tt, +INT_LIMIT, -INT_LIMIT, tt, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = -Omega_fun(+1,tt,ii, beta)*Omega_fun(-1,tt,jj, beta);
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)<ell
                        %Atensor(ii, jj, xLoop) = integral(func1y, tt, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = tt^(ii-1)*exp(-tt^2/2)*Omega_fun(+1,tt,jj, beta);
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)==ell
                        Atensor(ii, jj, xLoop) = 0;
                        
                    elseif sigmaVec(ii)==ell && sigmaVec(jj)>ell
                        %Atensor(ii, jj, xLoop) = integral(func1y, -INT_LIMIT, tt, 'AbsTol',1e-2, 'Method','iterated');                        
                        Atensor(ii, jj, xLoop) = -tt^(ii-1)*exp(-tt^2/2)*Omega_fun(-1,tt,jj, beta);
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)<ell
                        %Atensor(ii, jj, xLoop) = integral2(func2, -INT_LIMIT, tt, tt, +INT_LIMIT, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = Omega_fun(-1,tt,ii, beta)*Omega_fun(+1,tt,jj, beta);
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)==ell
                        %Atensor(ii, jj, xLoop) = integral(func1x, -INT_LIMIT, tt, 'AbsTol',1e-2, 'Method','iterated');
                        Atensor(ii, jj, xLoop) = tt^(jj-1)*exp(-tt^2/2)*Omega_fun(-1,tt,ii, beta);
                    elseif sigmaVec(ii)>ell && sigmaVec(jj)>ell
                        Atensor(ii, jj, xLoop) = integral2(func2, -INT_LIMIT, tt, -INT_LIMIT, tt, 'AbsTol',1e-2, 'Method','iterated');
                    else
                        error('Wrong sigmaVec!!!') 
                    end
                end %xLoop
            end %jj
        end %ii
                
        for ii = 1:N
            if sigmaVec(ii)<ell
				Atensor(ii, N+1, :) = Omega_fun(+1,x,ii, beta);
            elseif sigmaVec(ii)==ell
                Atensor(ii, N+1, :) = x.^(ii-1).*exp(-x.^2./2);
            else %sigmaVec(ii)>ell
				Atensor(ii, N+1, :) = Omega_fun(-1,x,ii, beta);
            end %end if            
        end %ii
        
        
    end %
    
    %Make the matrix skew-symmetric
    for xLoop = 1:lenX
        Atensor(:, :, xLoop) = Atensor(:, :, xLoop) - Atensor(:, :, xLoop).';
    end
    
    % Calculating determinant of the tensor        
    %% Method 1: zhc
    y = y+ coeff * Pf2D(Atensor);       

end %pLoop

end    
