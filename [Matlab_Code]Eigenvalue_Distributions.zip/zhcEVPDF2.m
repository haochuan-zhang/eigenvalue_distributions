function y = zhcEVPDF2(x, N, ell, EnsType) 

% ONLY for 2x2 GUE

% PDF of the ell-th largest eigenvalue
lenX = length(x);
y = zeros(lenX, 1);
%y = zeros(lenX, N); % each ev in a column, the largest the first

C2_GUE = 2^(N*(N-1)/2) / ( pi^(N/2) * prod(gamma(1:N)) );
Amat = zeros(N-1, N-1, lenX);
if ell==1
    for ii = 1:N-1
        for jj = 1:N-1
            Amat(ii, jj, :) = intgrRnegative(x, ii, jj);
        end
    end
    
else% ell==2
    for ii = 1:N-1
        for jj = 1:N-1
            Amat(ii, jj, :) = intgrRpositive(x, ii, jj);
        end
    end
end

    for xloop = 1:lenX
            y(xloop) = C2_GUE * exp(- x(xloop)^2)   ...
                * det(Amat(:,:, xloop));
    end

end


function output = intgrRpositive(x, ii, jj)
    output = ...
        1/2 * exp(-x.^2) .*...
        ( ...
          gamma((ii+jj+1)/2) * hypergeom((ii+jj+1)/2, 1/2, x.^2)  ...
          - ... 
          2 * gamma((ii+jj+2)/2) * hypergeom((ii+jj+2)/2, 3/2, x.^2) .* x ...
        );
end

function output = intgrRnegative(x, ii, jj)
    output = ...
        (-1)^(ii+jj+2) *1/2 * exp(-x.^2) .*...
        ( ...
          gamma((ii+jj+1)/2) * hypergeom((ii+jj+1)/2, 1/2, x.^2)  ...
          + ... 
          2 * gamma((ii+jj+2)/2) * hypergeom((ii+jj+2)/2, 3/2, x.^2) .* x ...
        );
end