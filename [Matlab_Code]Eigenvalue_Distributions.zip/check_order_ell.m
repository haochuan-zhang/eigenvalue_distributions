function is_ordered = check_order_ell(perm, ell)
%check if the permutation $perm$ meets the ordering requirement of
%p1>p2>..>p_{ell-1}, and p_{ell+1}>...>p_N; 
% if Yes, return TURE
% if No, retrun FALSE

N = length(perm);
%part1 = [1:1:ell-1];
%part2 = [ell+1:1:N];
is_ordered = 0<1; % true
for kk = [1:1:ell-2]
    if perm(kk)<=perm(kk+1)        
        is_ordered = 0>1; %false
    end
end

for kk = [ell+1:1:N-1]
    if perm(kk)<=perm(kk+1)        
        is_ordered = 0>1; %false
    end
end

