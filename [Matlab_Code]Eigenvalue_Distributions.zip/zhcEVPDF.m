function y = zhcEVPDF(x, N, ell, EnsType) 
% PDF of the ell-th largest eigenvalue
% lenX = length(x);
% y = zeros(lenX, 1);
%y = zeros(lenX, N); % each ev in a column, the largest the first

if EnsType == 'GOE'
    
elseif EnsType == 'GUE'
    y = inner_GUE_PDF(x, N, ell);
    
else % if NOT GUE or GOE
    error('Ensemble Type not supported!');
end % end if




end

